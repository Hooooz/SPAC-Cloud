from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml
from pydantic import BaseModel


class BrowserConfig(BaseModel):
    headless: bool = False
    locale: str = "zh-CN"
    timezone_id: str = "Asia/Shanghai"
    user_data_dir: str = "state/userdata"


class AppConfig(BaseModel):
    browser: BrowserConfig = BrowserConfig()
    # raw sections for flexibility
    cfg: Dict[str, Any] = {}


def load_config(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return data
