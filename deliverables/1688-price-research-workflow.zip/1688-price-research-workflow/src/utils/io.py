from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, Dict, List

import pandas as pd


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def write_json(path: str | Path, data: Any) -> None:
    p = Path(path)
    ensure_parent(p)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: str | Path, rows: Iterable[Dict[str, Any]], encoding: str = "utf-8-sig") -> None:
    p = Path(path)
    ensure_parent(p)
    df = pd.DataFrame(list(rows))
    df.to_csv(p, index=False, encoding=encoding)
