from __future__ import annotations

import argparse
from pathlib import Path

from playwright.sync_api import sync_playwright

from .utils.config import load_config


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = load_config(args.config)
    user_data_dir = Path(cfg.get("browser", {}).get("user_data_dir", "state/userdata"))
    user_data_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),
            headless=bool(cfg.get("browser", {}).get("headless", False)),
            locale=cfg.get("browser", {}).get("locale", "zh-CN"),
            timezone_id=cfg.get("browser", {}).get("timezone_id", "Asia/Shanghai"),
        )
        page = context.new_page()
        page.goto("https://login.1688.com/member/signin.htm", wait_until="domcontentloaded")
        print("[login] 浏览器已打开：请完成 1688 登录后关闭窗口。")
        page.wait_for_timeout(60 * 60 * 1000)  # 最长等 1 小时
        context.close()


if __name__ == "__main__":
    main()
