from __future__ import annotations

import argparse
from pathlib import Path

from playwright.sync_api import sync_playwright

from .collectors.1688 import build_search_url, collect_offers_from_page
from .utils.config import load_config
from .utils.io import write_csv, write_json


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--query", required=True)
    ap.add_argument("--pages", type=int, default=3)
    ap.add_argument("--out", required=True, help="output prefix, e.g. output/results")
    ap.add_argument("--slow-mo-ms", type=int, default=300)
    args = ap.parse_args()

    cfg = load_config(args.config)
    base_url = cfg.get("1688", {}).get("base_url", "https://s.1688.com/selloffer/offer_search.htm")
    default_params = cfg.get("1688", {}).get("default_params", {})
    user_data_dir = Path(cfg.get("browser", {}).get("user_data_dir", "state/userdata"))

    all_rows = []

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),
            headless=bool(cfg.get("browser", {}).get("headless", False)),
            locale=cfg.get("browser", {}).get("locale", "zh-CN"),
            timezone_id=cfg.get("browser", {}).get("timezone_id", "Asia/Shanghai"),
            slow_mo=args.slow_mo_ms,
        )
        page = context.new_page()

        for i in range(1, args.pages + 1):
            url = build_search_url(base_url=base_url, query=args.query, extra_params=default_params, begin_page=i)
            page.goto(url, wait_until="domcontentloaded")
            page.wait_for_timeout(1200)
            offers = collect_offers_from_page(page, query=args.query, page_no=i)
            all_rows.extend([o.to_dict() for o in offers])
            print(f"[run] page={i} offers={len(offers)}")

        context.close()

    out_prefix = Path(args.out)
    encoding = cfg.get("output", {}).get("encoding", "utf-8-sig")
    write_csv(str(out_prefix) + ".csv", all_rows, encoding=encoding)
    write_json(str(out_prefix) + ".json", all_rows)
    print(f"[done] rows={len(all_rows)} -> {out_prefix}.csv/.json")


if __name__ == "__main__":
    main()
