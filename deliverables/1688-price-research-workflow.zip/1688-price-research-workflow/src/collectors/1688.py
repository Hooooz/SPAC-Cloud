from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

from playwright.sync_api import Page


@dataclass
class Offer:
    query: str
    page: int
    rank: int
    title: str
    url: str
    shop: Optional[str]
    price_text: Optional[str]
    deal_text: Optional[str]
    moq_text: Optional[str]
    ship_from: Optional[str]
    collected_at: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def build_search_url(base_url: str, query: str, extra_params: Dict[str, Any] | None = None, begin_page: int = 1) -> str:
    params: Dict[str, Any] = {"keywords": query, "beginPage": str(begin_page)}
    if extra_params:
        params.update({k: v for k, v in extra_params.items() if v is not None and v != ""})
    return f"{base_url}?{urlencode(params, doseq=True)}"


def collect_offers_from_page(page: Page, query: str, page_no: int) -> List[Offer]:
    """
    尽量用“弱假设”选择器：
    - 1688 列表页结构可能变化；这里优先取链接/标题/价格的常见锚点。
    - 如果抓不到字段，优先在浏览器里用开发者工具定位，再更新选择器。
    """

    # 等待搜索结果区域出现（不强依赖具体 class 名）
    page.wait_for_timeout(800)

    cards = page.locator("a[href*='offer']").all()

    offers: List[Offer] = []
    seen = set()
    now = datetime.now().isoformat(timespec="seconds")

    # cards 里会混入很多链接，这里做一次“去重 + 过滤”
    rank = 0
    for a in cards:
        try:
            url = a.get_attribute("href") or ""
            if not url:
                continue
            if url.startswith("//"):
                url = "https:" + url
            if "offer" not in url:
                continue
            if url in seen:
                continue
            seen.add(url)

            title = (a.inner_text() or "").strip()
            if not title:
                # 有些卡片标题在子节点
                title = (a.text_content() or "").strip()

            # 向上找卡片容器以便拿到价格/店铺等（容错写法）
            container = a.locator("xpath=ancestor-or-self::*[self::div][1]")

            def pick_text(selector: str) -> Optional[str]:
                try:
                    loc = container.locator(selector).first
                    if loc.count() == 0:
                        return None
                    t = (loc.inner_text() or "").strip()
                    return t or None
                except Exception:
                    return None

            price_text = pick_text("text=/^¥/ ") or pick_text("span:has-text('¥')")
            shop = pick_text("a[href*='company']")
            deal_text = pick_text("text=/成交|付款|销量/")
            moq_text = pick_text("text=/起批|件起批|起订/")
            ship_from = pick_text("text=/发货地/")

            rank += 1
            offers.append(
                Offer(
                    query=query,
                    page=page_no,
                    rank=rank,
                    title=title,
                    url=url,
                    shop=shop,
                    price_text=price_text,
                    deal_text=deal_text,
                    moq_text=moq_text,
                    ship_from=ship_from,
                    collected_at=now,
                )
            )
        except Exception:
            continue

    return offers
