# Troubleshooting

## 1) 打开页面但抓不到数据/字段为空
- 可能是页面结构变了：更新 `src/collectors/1688.py` 里的选择器。
- 可能是未登录导致展示不全：先跑 `python -m src.login --config config.yaml`。
- 可能触发风控：
  - 降低抓取速度（`slow_mo_ms`）
  - 降低并发（当前脚本默认单页顺序抓取）
  - 适当减少页数

## 2) 运行报错：playwright browsers not installed
执行：
```bash
playwright install
```

## 3) Excel 打开 CSV 乱码
把 `config.yaml` 的 `output.encoding` 设为 `utf-8-sig`（默认已是）。

## 4) 想加字段
在 `Offer` 数据结构里加字段，并在 collector 里采集即可。
