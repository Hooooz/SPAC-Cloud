# 1688「结果调研」工作流（可移植包）

> 用途：把“在 1688 上按关键词调研报价区间/样本链接，并导出 CSV/JSON”的流程固化成可复用脚本。
> 
> 说明：1688 有登录/风控/反爬策略，**强烈建议使用 Playwright 的持久化浏览器 profile**（首次人工完成一次登录，后续复用登录态）。如你希望做到“完全无人值守自动登录”，需要额外的账号风控方案（不建议）。

## 目录
- `docs/WORKFLOW.md`：完整流程说明（从需求口径到交付物）
- `src/`：脚本代码
- `output/`：导出目录（默认生成 CSV/JSON）
- `config.example.yaml`：配置模板

## 快速开始（推荐：Python）

### 1) 环境要求
- Python 3.10+
- macOS / Windows / Linux 均可

### 2) 安装依赖
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
playwright install
```

### 3) 复制配置
```bash
cp config.example.yaml config.yaml
```

### 4) 首次登录（只做一次）
```bash
python -m src.login --config config.yaml
```
脚本会打开浏览器窗口：
- 你在弹出的 1688 页面完成登录
- 登录成功后直接关闭窗口
- 登录态会保存到 `state/` 目录（可复制到其他机器复用，但不保证跨环境稳定）

### 5) 跑调研导出
```bash
python -m src.run --config config.yaml --query "你的关键词" \
  --pages 3 --out output/results
```
会生成：
- `output/results.csv`
- `output/results.json`

## 交付物字段（默认）
- 标题、商品链接、店铺名
- 价格文本（区间/起批）、成交/销量（若页面可见）
- MOQ（若页面可见）、发货地（若页面可见）
- 抓取时间、查询关键词、页码、位置

## 常见问题
1. **抓不到/元素为空**：大概率是页面结构变化或风控，需要更新选择器；见 `docs/TROUBLESHOOTING.md`。
2. **登录失效**：重新跑一次 `src.login` 即可。
3. **想加筛选（地区/类目/起批量）**：在 `config.yaml` 里加 URL 参数或在 `src/collectors/1688.py` 里扩展。

